import "@/styles/globals.scss";
import Layout from "@/components/Layout";
import Head from "next/head";
import Script from "next/script";
import { Toaster, toast } from "sonner";
import "@/styles/checkbox.scss";
import "react-tooltip/dist/react-tooltip.css";
import { Tooltip } from "react-tooltip";
import Router from "next/router";
import { useState, useEffect } from "react";
import NProgress from "nprogress";
import "@/styles/nprogress.scss";
import "react-loading-skeleton/dist/skeleton.css";
import { GoogleAnalytics } from "@next/third-parties/google";

export default function App({ Component, pageProps }: any) {
  const [isLoading, setIsLoading] = useState(false);
  NProgress.configure({ showSpinner: false });
  const GTag: any = process.env.NEXT_PUBLIC_GT_MEASUREMENT_ID;
  // NProgress.configure({
  //   template: '<div class="bar" role="bar"><div class="peg"></div></div>'
  // });
  useEffect(() => {
    Router.events.on("routeChangeStart", (url) => {
      setIsLoading(true);
      NProgress.start();
    });

    Router.events.on("routeChangeComplete", (url) => {
      setIsLoading(false);
      NProgress.done(false);
    });

    Router.events.on("routeChangeError", (url) => {
      setIsLoading(false);
    });
  }, [Router]);

  useEffect(() => {
    // Disable context menu
    const disableContextMenu = (event: MouseEvent) => {
      event.preventDefault();
      toast.info("Context Menu has been disabled");
    };

    // Disable DevTools shortcut (CTRL+SHIFT+I)
    const disableDevToolsShortcut = (event: KeyboardEvent) => {
      if (
        (event.ctrlKey && event.shiftKey && event.key === "I") || // CTRL+SHIFT+I
        (event.ctrlKey && event.shiftKey && event.key === "J") || // CTRL+SHIFT+J
        (event.ctrlKey && event.shiftKey && event.key === "C") || // CTRL+SHIFT+C
        event.key === "F12" // F12
      ) {
        event.preventDefault();
        toast.info("Dev Tools has been disabled");
      }
    };

    // Add event listeners
    window.addEventListener("contextmenu", disableContextMenu);
    window.addEventListener("keydown", disableDevToolsShortcut);

    // Cleanup event listeners on unmount
    return () => {
      window.removeEventListener("contextmenu", disableContextMenu);
      window.removeEventListener("keydown", disableDevToolsShortcut);
    };
  }, []);

  return (
    <>
      <Head>
        <title>Aniora | Movie streaming website | Free</title>
        <meta
          name="description"
          content="Your Personal Movie Streaming Oasis"
        />
        <meta
          name="keywords"
          content="movie, streaming, tv, Aniora, stream. movie app, tv shows, movie download"
        />
        <meta
          name="google-site-verification"
          content="J0QUeScQSxufPJqGTaszgnI35U2jN98vVWSOkVR4HrI"
        />
        <link rel="manifest" href="manifest.json" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#f4f7fe" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Aniora" />
        <link rel="icon" href="/images/logo512.png" />
        <link rel="apple-touch-icon" href="/images/logo512.png" />
        {/* <link rel="mask-icon" href="/images/logo512.svg" color="#f4f7fe" /> */}
        <meta name="mobile-web-app-capable" content="yes" />
        {/* <meta name="msapplication-TileColor" content="#f4f7fe" /> */}
        <meta name="msapplication-tap-highlight" content="no" />
        <link rel="shortcut icon" href="/images/logo512.png" />
      </Head>
      <Layout>
        <Toaster
          toastOptions={{
            className: "sooner-toast-desktop",
          }}
          position="bottom-right"
        />
        <Toaster
          toastOptions={{
            className: "sooner-toast-mobile",
          }}
          position="top-center"
        />
        <Tooltip id="tooltip" className="react-tooltip" />
        <Component {...pageProps} />
      </Layout>
      <GoogleAnalytics gaId={GTag} />
      <Script
        disable-devtool-auto
        src="https://cdn.jsdelivr.net/npm/disable-devtool"
      />
    </>
  );
}
